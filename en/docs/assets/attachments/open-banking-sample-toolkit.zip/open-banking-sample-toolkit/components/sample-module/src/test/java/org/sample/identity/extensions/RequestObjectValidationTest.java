/*
 * Copyright (c) 2021, WSO2 Inc. (http://www.wso2.com). All Rights Reserved.
 *
 * This software is the property of WSO2 Inc. and its suppliers, if any.
 * Dissemination of any information or reproduction of any material contained
 * herein is strictly forbidden, unless permitted by WSO2 in accordance with
 * the WSO2 Commercial License available at http://wso2.com/licenses. For specific
 * language governing the permissions and limitations under this license,
 * please see the license as well as any agreement you’ve entered into with
 * WSO2 governing the purchase of this software and any associated services.
 */
package org.sample.identity.extensions;

import com.nimbusds.jose.JOSEObject;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jwt.PlainJWT;
import com.nimbusds.jwt.SignedJWT;
import com.wso2.openbanking.accelerator.identity.auth.extensions.request.validator.models.OBRequestObject;
import com.wso2.openbanking.accelerator.identity.auth.extensions.request.validator.models.ValidationResponse;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.wso2.carbon.identity.oauth2.RequestObjectException;
import org.wso2.carbon.identity.openidconnect.model.RequestObject;

import java.text.ParseException;
import java.util.Collections;

public class RequestObjectValidationTest {

    public static final String VALID_REQUEST = "eyJraWQiOiJEd01LZFdNbWo3UFdpbnZvcWZReVhWenlaNlEiLCJ0eXAiOiJKV1" +
            "QiLCJhbGciOiJQUzI1NiJ9.eyJhdWQiOiJodHRwczovL2xvY2FsaG9zdDo5NDQ2L29hdXRoMi90b2tlbiIsIm1heF9hZ2UiOjg2NDAw" +
            "LCJjcml0IjpbImI2NCIsImh0dHA6Ly9vcGVuYmFua2luZy5vcmcudWsvaWF0IiwiaHR0cDovL29wZW5iYW5raW5nLm9yZy51ay9pc3M" +
            "iLCJodHRwOi8vb3BlbmJhbmtpbmcub3JnLnVrL3RhbiJdLCJzY29wZSI6ImFjY291bnRzIG9wZW5pZCIsImV4cCI6MTk1NDcwODcxMC" +
            "wiY2xhaW1zIjp7ImlkX3Rva2VuIjp7ImFjciI6eyJ2YWx1ZXMiOlsidXJuOm9wZW5iYW5raW5nOnBzZDI6Y2EiLCJ1cm46b3BlbmJhb" +
            "mtpbmc6cHNkMjpzY2EiXSwiZXNzZW50aWFsIjp0cnVlfSwib3BlbmJhbmtpbmdfaW50ZW50X2lkIjp7InZhbHVlIjoiOTRmODU3M2Mt" +
            "NjA4MC00MDI1LThkOWItMDhlM2U5MjAwZGU3IiwiZXNzZW50aWFsIjp0cnVlfX0sInVzZXJpbmZvIjp7Im9wZW5iYW5raW5nX2ludGV" +
            "udF9pZCI6eyJ2YWx1ZSI6Ijk0Zjg1NzNjLTYwODAtNDAyNS04ZDliLTA4ZTNlOTIwMGRlNyIsImVzc2VudGlhbCI6dHJ1ZX19fSwiaX" +
            "NzIjoiMlgwbjlXU05tUGlxM1hUQjhkdEMwU2hzNXI4YSIsInJlc3BvbnNlX3R5cGUiOiJjb2RlIGlkX3Rva2VuIiwicmVkaXJlY3Rfd" +
            "XJpIjoiaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9yZWRpcmVjdHMvcmVkaXJlY3QxIiwic3RhdGUiOiIwcE4wTkJUSGN2Iiwibm9uY2Ui" +
            "OiJqQlhoT21PS0NCIiwiY2xpZW50X2lkIjoiMlgwbjlXU05tUGlxM1hUQjhkdEMwU2hzNXI4YSJ9.BjQIMnlqevJgj1zL25hmfKA9Ab" +
            "7qm2GvrkZAkxbTMNOxkxtKxQSt9QkLfycITEeM9YdGV5rh2FMdXxyex-WtO_H0G9zlKtsDyrsUw3_HWaBDd-61Hz6n65Few_f6bwtIg" +
            "HtW8oDeKpylUu01OsYtB_s4nnDw42ZCKv7zGzkTDkyoxoM2_b_AUqh-F3PNY9Arru5m1-FGDYi_zl4iQ3d3um_NYnhPhmC2wz2R9yms" +
            "flXBn9bd-d6nPKl_ftGnqmiBua7oKMd-3CMCFW9Uxig82PHbwHcuy1hYqa_7JoE58Zkr6baGur3YtgJ2381_8t5v19DJvjqhaodabfe" +
            "uNWR3GA";

    @Test
    public void testInvalidAudValue() throws ParseException, RequestObjectException {

        OBRequestObject<?> obRequestObject = getObRequestObject(VALID_REQUEST);
        ExtendedRequestObjectValidator extendedRequestObjectValidator = new ExtendedRequestObjectValidator();
        ValidationResponse validationResponse = extendedRequestObjectValidator
                .validateOBConstraints(obRequestObject, Collections.emptyMap());
        Assert.assertEquals(validationResponse.getViolationMessage(), "Incorrect aud value");
    }

    private OBRequestObject<?> getObRequestObject(String request) throws ParseException, RequestObjectException {

        RequestObject requestObject = new RequestObject();
        JOSEObject jwt = JOSEObject.parse(request);
        if (jwt.getHeader().getAlgorithm() == null || jwt.getHeader().getAlgorithm().equals(JWSAlgorithm.NONE)) {
            requestObject.setPlainJWT(PlainJWT.parse(request));
        } else {
            requestObject.setSignedJWT(SignedJWT.parse(request));
        }
        return new OBRequestObject<>(requestObject);
    }
}
