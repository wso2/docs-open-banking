# ------------------------------------------------------------------------
#
# Copyright (c) 2021, WSO2 Inc. (http://www.wso2.com). All Rights Reserved.
#
# This software is the property of WSO2 Inc. and its suppliers, if any.
# Dissemination of any information or reproduction of any material contained
# herein is strictly forbidden, unless permitted by WSO2 in accordance with
# the WSO2 Commercial License available at http://wso2.com/licenses. For specific
# language governing the permissions and limitations under this license,
# please see the license as well as any agreement you’ve entered into with
# WSO2 governing the purchase of this software and any associated services.
#
# ------------------------------------------------------------------------

$PRODUCT_HOME = $args[0]

# set product home
if ($null -eq $PRODUCT_HOME)
{
    $PRODUCT_HOME = $pwd.path
    Write-Output "Product Home: $PRODUCT_HOME"
}

# validate product home
if (-NOT(Test-Path "$PRODUCT_HOME/repository/components"))
{
    Write-Output "`n`aERROR:specified product path is not a valid carbon product path`n"
    exit 2
}
else
{
    Write-Output "`nValid carbon product path.s`n"
}

foreach ($item in (Get-ChildItem -path "$($PRODUCT_HOME)/repository/components/dropins" -Recurse -Filter 'com.wso2.*').'Name') {cmd.exe /c "mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile=$($PRODUCT_HOME)/repository/components/dropins/$($item) -Dpackaging=jar"}
foreach ($item in (Get-ChildItem -path "$($PRODUCT_HOME)/repository/components/lib" -Recurse -Filter 'com.wso2.*').'Name') {cmd.exe /c "mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile=$($PRODUCT_HOME)/repository/components/lib/$($item) -Dpackaging=jar"}
foreach ($item in (Get-ChildItem -path "$($PRODUCT_HOME)/repository/components/plugins" -Recurse -Filter 'com.wso2.*').'Name') {cmd.exe /c "mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile=$($PRODUCT_HOME)/repository/components/plugins/$($item) -Dpackaging=jar"}

foreach ($item in (Get-ChildItem -path "$($PRODUCT_HOME)/repository/components/dropins" -Recurse -Filter 'org.wso2.*').'Name') {cmd.exe /c "mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile=$($PRODUCT_HOME)/repository/components/dropins/$($item) -Dpackaging=jar"}
foreach ($item in (Get-ChildItem -path "$($PRODUCT_HOME)/repository/components/lib" -Recurse -Filter 'org.wso2.*').'Name') {cmd.exe /c "mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile=$($PRODUCT_HOME)/repository/components/lib/$($item) -Dpackaging=jar"}
foreach ($item in (Get-ChildItem -path "$($PRODUCT_HOME)/repository/components/plugins" -Recurse -Filter 'org.wso2.*').'Name') {cmd.exe /c "mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile=$($PRODUCT_HOME)/repository/components/plugins/$($item) -Dpackaging=jar"}

