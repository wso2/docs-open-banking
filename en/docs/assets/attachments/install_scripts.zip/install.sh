#!/bin/bash
# ------------------------------------------------------------------------
#
# Copyright (c) 2021, WSO2 Inc. (http://www.wso2.com). All Rights Reserved.
#
# This software is the property of WSO2 Inc. and its suppliers, if any.
# Dissemination of any information or reproduction of any material contained
# herein is strictly forbidden, unless permitted by WSO2 in accordance with
# the WSO2 Commercial License available at http://wso2.com/licenses. For specific
# language governing the permissions and limitations under this license,
# please see the license as well as any agreement you’ve entered into with
# WSO2 governing the purchase of this software and any associated services.
#
# ------------------------------------------------------------------------

PRODUCT_HOME=$1

# set product home
if [ "${PRODUCT_HOME}" == "" ]; then
  PRODUCT_HOME=$(pwd)
  echo "Product home is: ${PRODUCT_HOME}"
fi

# validate product home
if [ ! -d "${PRODUCT_HOME}/repository/components" ]; then
  echo -e "\n\aERROR:specified product path is not a valid carbon product path\n"
  exit 2
else
  echo -e "\nValid carbon product path.\n"
fi

find "${PRODUCT_HOME}"/repository/components/dropins -name "com.wso2.*" -exec mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile={} -Dpackaging=jar \;
find "${PRODUCT_HOME}"/repository/components/lib -name "com.wso2.*" -exec mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile={} -Dpackaging=jar \;
find "${PRODUCT_HOME}"/repository/components/plugins -name "com.wso2.*" -exec mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile={} -Dpackaging=jar \;

find "${PRODUCT_HOME}"/repository/components/dropins -name "org.wso2.*" -exec mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile={} -Dpackaging=jar \;
find "${PRODUCT_HOME}"/repository/components/lib -name "org.wso2.*" -exec mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile={} -Dpackaging=jar \;
find "${PRODUCT_HOME}"/repository/components/plugins -name "org.wso2.*" -exec mvn org.apache.maven.plugins:maven-install-plugin:2.5.2:install-file -Dfile={} -Dpackaging=jar \;
